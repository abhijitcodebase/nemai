const PageHeader = () => {
  return <header className="page-header">Header</header>;
};
export default PageHeader;
