const Aside = () => {
  return (
    <aside className="left-panel">
      <ul>
        <li>Link 1</li>
        <li>Link 1</li>
        <li>Link 1</li>
        <li>Link 1</li>
        <li>Link 1</li>
        <li>Link 1</li>
        <li>Link 1</li>
        <li>Link 1</li>
      </ul>
    </aside>
  );
};

export default Aside;
