const Card = () => {
  return (
    <div className="card">
      <div>Image</div>
      <p>Name</p>
      <p>Description</p>
      <p>Price: </p>
    </div>
  );
};

export default Card;
